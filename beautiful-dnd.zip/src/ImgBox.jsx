import React from "react";
import { Draggable } from "react-beautiful-dnd";

export default function ImgBox({ imgURL }) {
  return (
    <div className="relative group">
      <img
        className="h-auto border border-violet-500 max-w-full rounded-lg  relative"
        src={imgURL}
        alt=""
      />
      <div className="absolute inset-0 bg-black rounded-lg opacity-0 group-hover:opacity-50 transition-opacity cursor-pointer"></div>
    </div>
  );
}
